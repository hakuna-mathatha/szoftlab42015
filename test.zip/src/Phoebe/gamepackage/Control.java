package Phoebe.gamepackage;

public class Control {
	
	
	public Control(){
		
	}

	public void turnLeft(Bot bot) {};

	public void turnRight(Bot bot) {};

	public void accelerate(Bot bot) {};

	public void slowDown(Bot bot) {};

	public void putOil(Bot bot) {};

	public void putPutty(Bot bot) {};

}