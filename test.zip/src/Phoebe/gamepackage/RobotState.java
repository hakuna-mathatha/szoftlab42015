package Phoebe.gamepackage;

public enum RobotState {
	died, jump, active, oil, putty, pure

}