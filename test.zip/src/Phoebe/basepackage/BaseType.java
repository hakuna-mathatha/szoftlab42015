package Phoebe.basepackage;

public enum BaseType {
	normalRobot, cleanerRobot, oil, pure, putty, edge
}




