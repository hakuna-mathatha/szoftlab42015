Important:

Do not forgert to setup Java path!

How to use:

1. Open cmd
2. Locate application folder
3. Run compile.bat
4. Run runTest.bat for testing

Locations:

- sources are in src
- map data is in data
- test result is in results
- expected results are in expectedresults
- predefined test methods are in predefinedtests

